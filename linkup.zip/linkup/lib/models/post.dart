import 'package:flutter/material.dart';

enum PostType { service, annonce, recrutement, standard }

class Post {
  final String id;
  final String authorId;
  final String authorName;
  final String authorInitials;
  final Color authorColor;
  final String authorProfession;
  final String timeAgo;
  final String body;
  final String? imageUrl;
  final PostType type;
  final String? domain;
  final Color? domainColor;
  final String? ctaLabel;
  final Color? ctaColor;
  final bool showFollowContact;
  final int likes;
  final int comments;
  final bool isVerified;

  const Post({
    required this.id,
    required this.authorId,
    required this.authorName,
    required this.authorInitials,
    required this.authorColor,
    required this.authorProfession,
    required this.timeAgo,
    this.body = '',
    this.imageUrl,
    required this.type,
    this.domain,
    this.domainColor,
    this.ctaLabel,
    this.ctaColor,
    this.showFollowContact = false,
    this.likes = 0,
    this.comments = 0,
    this.isVerified = false,
  });
}

// ─── Sample data ──────────────────────────────────────────────────────────────
final kSamplePosts = [
  Post(
    id: 'p1',
    authorId: 'u3',
    authorName: 'Fatou K.',
    authorInitials: 'FK',
    authorColor: const Color(0xFF6C63FF),
    authorProfession: 'Électricienne · Lomé',
    timeAgo: '2h',
    body: 'Disponible pour vos projets de design ! 🤩',
    imageUrl: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=800&q=80',
    type: PostType.service,
    domain: 'Électricité',
    domainColor: Color(0xFF6C63FF),
    showFollowContact: true,
    likes: 48,
    comments: 12,
    isVerified: true,
  ),
  Post(
    id: 'p2',
    authorId: 'u4',
    authorName: 'Jean Tech',
    authorInitials: 'JT',
    authorColor: const Color(0xFF14B8A6),
    authorProfession: 'Développeur Flutter',
    timeAgo: '5h',
    body: 'Offre d\'emploi : Vendeur – Boutique à Adidogomé',
    imageUrl: 'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?w=800&q=80',
    type: PostType.recrutement,
    domain: 'Recrutement',
    domainColor: Color(0xFF14B8A6),
    ctaLabel: 'Postuler',
    ctaColor: Color(0xFF6C63FF),
    likes: 68,
    comments: 24,
  ),
  Post(
    id: 'p3',
    authorId: 'u2',
    authorName: 'Patrick Mensah',
    authorInitials: 'PM',
    authorColor: const Color(0xFFF97316),
    authorProfession: 'Maçon certifié · Lomé',
    timeAgo: '1j',
    body: 'Chantier terminé avec succès ! Rénovation complète d\'une villa à Agoè. 🏗️',
    imageUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800&q=80',
    type: PostType.standard,
    domain: 'Bâtiment',
    domainColor: Color(0xFFF97316),
    likes: 134,
    comments: 31,
    isVerified: true,
  ),
];
