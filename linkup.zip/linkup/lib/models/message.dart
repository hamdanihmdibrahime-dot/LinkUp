import 'package:flutter/material.dart';

class Conversation {
  final String id;
  final String name;
  final String initials;
  final Color color;
  final String lastMessage;
  final String time;
  final int unreadCount;
  final bool isOnline;

  const Conversation({
    required this.id,
    required this.name,
    required this.initials,
    required this.color,
    required this.lastMessage,
    required this.time,
    this.unreadCount = 0,
    this.isOnline = false,
  });
}

final kSampleConversations = [
  const Conversation(
    id: 'c1',
    name: 'Amina Traoré',
    initials: 'AT',
    color: Color(0xFF6C63FF),
    lastMessage: 'Oui, disponible demain à 9h…',
    time: '09:42',
    unreadCount: 2,
    isOnline: true,
  ),
  const Conversation(
    id: 'c2',
    name: 'TogoBâtir Construction',
    initials: 'TB',
    color: Color(0xFFF97316),
    lastMessage: 'Votre devis est prêt, veuillez consulter…',
    time: 'Hier',
    unreadCount: 1,
    isOnline: false,
  ),
  const Conversation(
    id: 'c3',
    name: 'Patrick Mensah',
    initials: 'PM',
    color: Color(0xFF14B8A6),
    lastMessage: 'Merci pour votre confiance, le chantier…',
    time: 'Lun',
    unreadCount: 0,
    isOnline: false,
  ),
  const Conversation(
    id: 'c4',
    name: 'Sandra K.',
    initials: 'SK',
    color: Color(0xFFA78BFA),
    lastMessage: 'Je vous envoie les photos de la panne',
    time: 'Dim',
    unreadCount: 0,
    isOnline: true,
  ),
];
