import 'package:flutter/material.dart';

enum NotifType { alert, review, verified, like, follow, message }

class NotifItem {
  final String id;
  final NotifType type;
  final String title;
  final String subtitle;
  final String timeAgo;
  final bool isRead;

  const NotifItem({
    required this.id,
    required this.type,
    required this.title,
    required this.subtitle,
    required this.timeAgo,
    this.isRead = false,
  });

  Color get bgColor {
    switch (type) {
      case NotifType.alert:   return const Color(0xFFEDE9FE);
      case NotifType.review:  return const Color(0xFFFFEDD5);
      case NotifType.verified:return const Color(0xFFCCFBF1);
      case NotifType.like:    return const Color(0xFFFEE2E2);
      case NotifType.follow:  return const Color(0xFFEDE9FE);
      case NotifType.message: return const Color(0xFFEDE9FE);
    }
  }

  Color get iconColor {
    switch (type) {
      case NotifType.alert:   return const Color(0xFF6C63FF);
      case NotifType.review:  return const Color(0xFFF97316);
      case NotifType.verified:return const Color(0xFF14B8A6);
      case NotifType.like:    return const Color(0xFFFF5C5C);
      case NotifType.follow:  return const Color(0xFF6C63FF);
      case NotifType.message: return const Color(0xFF6C63FF);
    }
  }

  IconData get icon {
    switch (type) {
      case NotifType.alert:    return Icons.notifications_active_outlined;
      case NotifType.review:   return Icons.star_outline;
      case NotifType.verified: return Icons.verified_outlined;
      case NotifType.like:     return Icons.favorite_outline;
      case NotifType.follow:   return Icons.person_add_outlined;
      case NotifType.message:  return Icons.chat_bubble_outline;
    }
  }
}

final kSampleNotifs = [
  const NotifItem(
    id: 'n1',
    type: NotifType.alert,
    title: 'Alerte : Électricien disponible à Lomé',
    subtitle: 'Fatou K. est en ligne · il y a 5 min',
    timeAgo: '5 min',
  ),
  const NotifItem(
    id: 'n2',
    type: NotifType.review,
    title: 'Nouvel avis 5 étoiles reçu',
    subtitle: 'Eric M. a évalué votre profil · il y a 1h',
    timeAgo: '1h',
    isRead: true,
  ),
  const NotifItem(
    id: 'n3',
    type: NotifType.verified,
    title: 'Profil vérifié avec succès',
    subtitle: 'Vous avez obtenu le badge Pro Certifié',
    timeAgo: '3h',
    isRead: true,
  ),
  const NotifItem(
    id: 'n4',
    type: NotifType.like,
    title: 'Patrick M. a aimé votre publication',
    subtitle: '· il y a 2h',
    timeAgo: '2h',
    isRead: true,
  ),
  const NotifItem(
    id: 'n5',
    type: NotifType.follow,
    title: 'Yao Bekoé vous suit maintenant',
    subtitle: 'Lundi · Maçon certifié',
    timeAgo: 'Lun',
    isRead: true,
  ),
];
