import 'package:flutter/material.dart';

enum ProductType { product, service }

class Product {
  final String id;
  final String title;
  final String price;
  final String currency;
  final String? imageUrl;
  final ProductType type;
  final bool isVerified;
  final bool isPromo;
  final Color? accent;
  final String ctaLabel;

  const Product({
    required this.id,
    required this.title,
    required this.price,
    this.currency = 'FCFA',
    this.imageUrl,
    this.type = ProductType.product,
    this.isVerified = false,
    this.isPromo = false,
    this.accent,
    this.ctaLabel = 'Acheter',
  });
}

// ─── Sample data ──────────────────────────────────────────────────────────────
final kSampleProducts = [
  Product(
    id: 'pr1',
    title: 'iPhone 11 Pro 256 Go',
    price: '280 000',
    imageUrl: 'https://images.unsplash.com/photo-1574920162043-b872873f19bc?w=400&q=80',
    isVerified: true,
    isPromo: true,
    ctaLabel: 'Acheter',
  ),
  Product(
    id: 'pr2',
    title: 'Vélo VTT Tout Terrain',
    price: '75 000',
    imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80',
    isVerified: true,
    ctaLabel: 'Acheter',
  ),
  Product(
    id: 'pr3',
    title: 'Installation électrique',
    price: 'Devis gratuit',
    currency: '',
    imageUrl: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=400&q=80',
    type: ProductType.service,
    isVerified: true,
    accent: const Color(0xFF14B8A6),
    ctaLabel: 'Demander',
  ),
  Product(
    id: 'pr4',
    title: 'Déménagement complet',
    price: 'Dès 50 000',
    imageUrl: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=400&q=80',
    type: ProductType.service,
    isVerified: true,
    accent: const Color(0xFF14B8A6),
    ctaLabel: 'Demander',
  ),
];
