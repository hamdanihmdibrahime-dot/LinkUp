class AppUser {
  final String id;
  final String name;
  final String initials;
  final String profession;
  final String location;
  final String bio;
  final String? avatarUrl;
  final String badge; // 'or' | 'argent' | ''
  final bool isVerified;
  final double rating;
  final int reviewCount;
  final int postCount;
  final int followerCount;
  final int reliabilityPercent;
  final bool isOnline;

  const AppUser({
    required this.id,
    required this.name,
    required this.initials,
    required this.profession,
    required this.location,
    this.bio = '',
    this.avatarUrl,
    this.badge = '',
    this.isVerified = false,
    this.rating = 0,
    this.reviewCount = 0,
    this.postCount = 0,
    this.followerCount = 0,
    this.reliabilityPercent = 0,
    this.isOnline = false,
  });
}

// ─── Sample data (remplacer par Firestore plus tard) ─────────────────────────
final kSampleUsers = [
  const AppUser(
    id: 'u1',
    name: 'Amina Traoré',
    initials: 'AT',
    profession: 'Plombière certifiée',
    location: 'Lomé, Togo',
    bio: 'Spécialiste installation & réparation. 8 ans d\'expérience. Disponible 7j/7.',
    badge: 'or',
    isVerified: true,
    rating: 4.9,
    reviewCount: 148,
    postCount: 214,
    followerCount: 1200,
    reliabilityPercent: 98,
    isOnline: true,
  ),
  const AppUser(
    id: 'u2',
    name: 'Patrick Mensah',
    initials: 'PM',
    profession: 'Maçon certifié',
    location: 'Lomé, Togo',
    badge: 'or',
    isVerified: true,
    rating: 5.0,
    reviewCount: 120,
    postCount: 87,
    followerCount: 940,
    reliabilityPercent: 100,
    isOnline: false,
  ),
  const AppUser(
    id: 'u3',
    name: 'Fatou K.',
    initials: 'FK',
    profession: 'Électricienne',
    location: 'Lomé, Togo',
    badge: 'argent',
    isVerified: true,
    rating: 4.8,
    reviewCount: 85,
    postCount: 56,
    followerCount: 720,
    reliabilityPercent: 95,
    isOnline: true,
  ),
  const AppUser(
    id: 'u4',
    name: 'Jean Tech',
    initials: 'JT',
    profession: 'Développeur Flutter',
    location: 'Adidogomé',
    badge: '',
    isVerified: false,
    rating: 4.6,
    reviewCount: 32,
    postCount: 41,
    followerCount: 310,
    reliabilityPercent: 88,
    isOnline: false,
  ),
  const AppUser(
    id: 'u5',
    name: 'TogoBâtir Construction',
    initials: 'TB',
    profession: 'Entreprise BTP',
    location: 'Adidogomé',
    badge: 'argent',
    isVerified: true,
    rating: 4.6,
    reviewCount: 95,
    postCount: 62,
    followerCount: 1540,
    reliabilityPercent: 92,
    isOnline: true,
  ),
];
