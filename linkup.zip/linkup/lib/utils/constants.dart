import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  COLOURS
// ─────────────────────────────────────────────────────────────────────────────
abstract class AppColors {
  // Brand
  static const primary      = Color(0xFF6C63FF); // violet principal
  static const primaryLight = Color(0xFFA78BFA); // violet clair
  static const primaryBg    = Color(0xFFEDE9FE); // fond violet tès clair

  // Accents
  static const teal         = Color(0xFF14B8A6);
  static const tealBg       = Color(0xFFCCFBF1);
  static const orange       = Color(0xFFF97316);
  static const orangeBg     = Color(0xFFFFEDD5);

  // Statuts
  static const gold         = Color(0xFFF59E0B);
  static const goldBg       = Color(0xFFFEF3C7);
  static const red          = Color(0xFFFF5C5C);
  static const redBg        = Color(0xFFFEE2E2);
  static const green        = Color(0xFF22C55E);
  static const greenBg      = Color(0xFFDCFCE7);

  // Neutres
  static const scaffold     = Color(0xFFF8F7FF);
  static const white        = Colors.white;
  static const textPrimary  = Color(0xFF1A1A2E);
  static const textSecond   = Color(0xFF6B7280);
  static const textHint     = Color(0xFF9CA3AF);
  static const border       = Color(0xFFE5E7EB);
  static const borderLight  = Color(0xFFF3F4F6);
  static const shimmer      = Color(0xFFF1F0FF);
}

// ─────────────────────────────────────────────────────────────────────────────
//  THEME
// ─────────────────────────────────────────────────────────────────────────────
abstract class AppTheme {
  static ThemeData get light => ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.scaffold,
        colorScheme: const ColorScheme.light(
          primary: AppColors.primary,
          secondary: AppColors.teal,
          error: AppColors.red,
        ),
        textTheme: GoogleFonts.nunitoTextTheme(),
        appBarTheme: AppBarTheme(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          elevation: 0,
          titleTextStyle: GoogleFonts.nunito(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: Colors.white,
            letterSpacing: .5,
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            textStyle: GoogleFonts.nunito(
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: AppColors.textPrimary,
            side: const BorderSide(color: AppColors.border),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            textStyle: GoogleFonts.nunito(
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: AppColors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25),
            borderSide: const BorderSide(color: AppColors.border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25),
            borderSide: const BorderSide(color: AppColors.border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(25),
            borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
          ),
          contentPadding: const EdgeInsets.symmetric(
              horizontal: 16, vertical: 10),
          hintStyle: GoogleFonts.nunito(
              fontSize: 13, color: AppColors.textHint),
        ),
      );

  // ── Text helpers ───────────────────────────────────────────────────────────
  static TextStyle h1({Color color = AppColors.textPrimary}) =>
      GoogleFonts.nunito(fontSize: 22, fontWeight: FontWeight.w800, color: color);

  static TextStyle h2({Color color = AppColors.textPrimary}) =>
      GoogleFonts.nunito(fontSize: 17, fontWeight: FontWeight.w700, color: color);

  static TextStyle body({Color color = AppColors.textPrimary, double size = 14}) =>
      GoogleFonts.nunito(fontSize: size, fontWeight: FontWeight.w600, color: color);

  static TextStyle caption({Color color = AppColors.textSecond}) =>
      GoogleFonts.nunito(fontSize: 12, color: color);

  // ── Button helpers ─────────────────────────────────────────────────────────
  static ButtonStyle filledBtn(Color bg, {Color fg = Colors.white}) =>
      ElevatedButton.styleFrom(
        backgroundColor: bg,
        foregroundColor: fg,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        textStyle: GoogleFonts.nunito(fontSize: 13, fontWeight: FontWeight.w700),
      );

  static ButtonStyle outlineBtn({Color color = AppColors.border}) =>
      OutlinedButton.styleFrom(
        side: BorderSide(color: color),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        textStyle: GoogleFonts.nunito(fontSize: 13, fontWeight: FontWeight.w700),
      );
}

// ─────────────────────────────────────────────────────────────────────────────
//  SPACING
// ─────────────────────────────────────────────────────────────────────────────
abstract class Sp {
  static const xs  = 4.0;
  static const sm  = 8.0;
  static const md  = 12.0;
  static const lg  = 16.0;
  static const xl  = 24.0;
  static const xxl = 32.0;
}

// ─────────────────────────────────────────────────────────────────────────────
//  RADIUS
// ─────────────────────────────────────────────────────────────────────────────
abstract class Rad {
  static const sm  = 8.0;
  static const md  = 12.0;
  static const lg  = 16.0;
  static const xl  = 24.0;
  static const full = 999.0;
}
