import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/notifications_provider.dart';
import '../utils/constants.dart';
import '../widgets/notification_card.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<NotificationsProvider>();
    final notifs = provider.notifs;

    final todayNotifs = notifs.where((n) =>
        ['5 min', '1h', '2h', '3h'].contains(n.timeAgo)).toList();
    final weekNotifs = notifs.where((n) =>
        !['5 min', '1h', '2h', '3h'].contains(n.timeAgo)).toList();

    return Scaffold(
      backgroundColor: AppColors.scaffold,
      appBar: AppBar(
        title: const Text('Notifications'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        actions: [
          TextButton(
            onPressed: provider.markAllRead,
            child: const Text('Tout lire', style: TextStyle(color: Colors.white70, fontSize: 13)),
          ),
        ],
      ),
      body: ListView(
        children: [
          if (todayNotifs.isNotEmpty) ...[
            _SectionHeader(label: "Aujourd'hui"),
            ...todayNotifs.map((n) => Column(
                  children: [
                    NotificationCard(notif: n),
                    const Divider(height: 0, color: AppColors.borderLight),
                  ],
                )),
          ],
          if (weekNotifs.isNotEmpty) ...[
            _SectionHeader(label: 'Cette semaine'),
            ...weekNotifs.map((n) => Column(
                  children: [
                    NotificationCard(notif: n),
                    const Divider(height: 0, color: AppColors.borderLight),
                  ],
                )),
          ],
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String label;
  const _SectionHeader({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
      child: Text(
        label,
        style: AppTheme.caption(color: AppColors.textSecond)
            .copyWith(fontWeight: FontWeight.w700, fontSize: 11),
      ),
    );
  }
}
