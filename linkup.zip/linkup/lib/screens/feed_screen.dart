import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/user.dart';
import '../providers/feed_provider.dart';
import '../utils/constants.dart';
import '../widgets/post_card.dart';
import '../widgets/user_avatar.dart';

class FeedScreen extends StatelessWidget {
  const FeedScreen({super.key});

  static const _storyUsers = [
    AppUser(id: 's0', name: 'Votre story', initials: '+',  profession: '', location: '', isOnline: false),
    AppUser(id: 's1', name: 'Fatou',       initials: 'FK', profession: '', location: '', isOnline: true),
    AppUser(id: 's2', name: 'Jean T.',     initials: 'JT', profession: '', location: '', isOnline: false),
    AppUser(id: 's3', name: 'Patrick',     initials: 'PM', profession: '', location: '', isOnline: true),
    AppUser(id: 's4', name: 'Amina',       initials: 'AT', profession: '', location: '', isOnline: false),
    AppUser(id: 's5', name: 'TogoBâtir',   initials: 'TB', profession: '', location: '', isOnline: true),
  ];

  static const _storyColors = [
    AppColors.primary,
    Color(0xFF6C63FF),
    Color(0xFF14B8A6),
    Color(0xFFF97316),
    Color(0xFFA78BFA),
    Color(0xFFF59E0B),
  ];

  @override
  Widget build(BuildContext context) {
    final feed = context.watch<FeedProvider>();

    return RefreshIndicator(
      color: AppColors.primary,
      onRefresh: feed.refresh,
      child: CustomScrollView(
        slivers: [
          // Stories
          SliverToBoxAdapter(child: _buildStories()),
          // Domain filters
          SliverToBoxAdapter(child: _buildFilters(context, feed)),
          // Posts
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (ctx, i) => PostCard(
                post: feed.posts[i],
                onLike: () => feed.toggleLike(feed.posts[i].id),
              ),
              childCount: feed.posts.length,
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 20)),
        ],
      ),
    );
  }

  Widget _buildStories() {
    return Container(
      color: AppColors.white,
      height: 95,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        itemCount: _storyUsers.length,
        separatorBuilder: (_, __) => const SizedBox(width: 14),
        itemBuilder: (ctx, i) {
          final u = _storyUsers[i];
          final isOwn = i == 0;
          return Column(
            children: [
              isOwn
                  ? Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.primaryBg,
                        border: Border.all(color: AppColors.primary, width: 2),
                      ),
                      child: const Icon(Icons.add, color: AppColors.primary, size: 24),
                    )
                  : StoryRing(
                      hasStory: true,
                      isViewed: i > 3,
                      child: UserAvatar(
                        initials: u.initials,
                        color: _storyColors[i],
                        radius: 22,
                        isOnline: u.isOnline,
                      ),
                    ),
              const SizedBox(height: 5),
              Text(
                u.name,
                style: AppTheme.caption(),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildFilters(BuildContext context, FeedProvider feed) {
    return Container(
      color: AppColors.scaffold,
      height: 46,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        itemCount: feed.filters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (ctx, i) {
          final f = feed.filters[i];
          final selected = feed.activeFilter == f;
          return GestureDetector(
            onTap: () => feed.setFilter(f),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: selected ? AppColors.primary : AppColors.white,
                borderRadius: BorderRadius.circular(Rad.full),
                border: Border.all(
                  color: selected ? AppColors.primary : AppColors.border,
                ),
              ),
              child: Text(
                f,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: selected ? Colors.white : AppColors.textSecond,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
