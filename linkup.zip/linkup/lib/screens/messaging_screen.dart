import 'package:flutter/material.dart';
import '../models/message.dart';
import '../utils/constants.dart';
import '../widgets/search_bar.dart';
import '../widgets/user_avatar.dart';

class MessagingScreen extends StatelessWidget {
  const MessagingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.scaffold,
      appBar: AppBar(
        title: const Text('Messages'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            color: AppColors.white,
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
            child: LinkUpSearchBar(
              controller: TextEditingController(),
              hint: 'Rechercher une conversation…',
            ),
          ),
          Expanded(
            child: ListView.separated(
              itemCount: kSampleConversations.length,
              separatorBuilder: (_, __) =>
                  const Divider(height: 0, color: AppColors.borderLight),
              itemBuilder: (ctx, i) =>
                  _ConversationTile(conv: kSampleConversations[i]),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.edit, color: Colors.white),
        onPressed: () {},
      ),
    );
  }
}

class _ConversationTile extends StatelessWidget {
  final Conversation conv;
  const _ConversationTile({required this.conv});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => _ChatScreen(conv: conv)),
      ),
      child: Container(
        color: conv.unreadCount > 0 ? AppColors.primaryBg.withOpacity(0.4) : AppColors.white,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            UserAvatar(
              initials: conv.initials,
              color: conv.color,
              radius: 24,
              isOnline: conv.isOnline,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(conv.name,
                      style: AppTheme.body(size: 14).copyWith(
                        fontWeight: conv.unreadCount > 0 ? FontWeight.w800 : FontWeight.w600,
                      )),
                  const SizedBox(height: 3),
                  Text(conv.lastMessage,
                      style: AppTheme.caption(
                        color: conv.unreadCount > 0 ? AppColors.textPrimary : AppColors.textSecond,
                      ),
                      overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(conv.time, style: AppTheme.caption(color: AppColors.textHint)),
                const SizedBox(height: 4),
                if (conv.unreadCount > 0)
                  Container(
                    width: 20,
                    height: 20,
                    decoration: const BoxDecoration(
                      color: AppColors.primary,
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Text('${conv.unreadCount}',
                          style: const TextStyle(
                              fontSize: 11, color: Colors.white, fontWeight: FontWeight.w700)),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── Simple Chat Screen ───────────────────────────────────────────────────────

class _ChatScreen extends StatelessWidget {
  final Conversation conv;
  const _ChatScreen({required this.conv});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        title: Row(
          children: [
            UserAvatar(initials: conv.initials, color: conv.color, radius: 18, isOnline: conv.isOnline),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(conv.name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                if (conv.isOnline)
                  const Text('En ligne', style: TextStyle(fontSize: 11, color: Color(0xFF86efac))),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(icon: const Icon(Icons.phone_outlined), onPressed: () {}),
          IconButton(icon: const Icon(Icons.more_vert), onPressed: () {}),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              reverse: true,
              padding: const EdgeInsets.all(14),
              children: const [
                _ChatBubble(text: 'Oui, je suis disponible demain matin à 9h pour l\'intervention.', isMine: false),
                _ChatBubble(text: 'Bonjour, êtes-vous disponible pour une réparation urgente ?', isMine: true),
              ],
            ),
          ),
          _buildInput(),
        ],
      ),
    );
  }

  Widget _buildInput() {
    return Container(
      color: AppColors.white,
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            IconButton(icon: const Icon(Icons.attach_file_outlined, color: AppColors.textSecond), onPressed: () {}),
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.scaffold,
                  borderRadius: BorderRadius.circular(Rad.full),
                  border: Border.all(color: AppColors.border),
                ),
                child: Text('Écrire un message…', style: AppTheme.caption(color: AppColors.textHint)),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              width: 40,
              height: 40,
              decoration: const BoxDecoration(
                color: AppColors.primary,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.send, color: Colors.white, size: 18),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChatBubble extends StatelessWidget {
  final String text;
  final bool isMine;
  const _ChatBubble({required this.text, required this.isMine});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
        decoration: BoxDecoration(
          color: isMine ? AppColors.primary : AppColors.white,
          borderRadius: BorderRadius.circular(Rad.md).copyWith(
            bottomRight: isMine ? Radius.zero : const Radius.circular(Rad.md),
            bottomLeft: isMine ? const Radius.circular(Rad.md) : Radius.zero,
          ),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 4, offset: const Offset(0, 2)),
          ],
        ),
        child: Text(
          text,
          style: AppTheme.body(
            size: 13,
            color: isMine ? Colors.white : AppColors.textPrimary,
          ),
        ),
      ),
    );
  }
}
