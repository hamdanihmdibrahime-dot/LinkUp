import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../utils/constants.dart';
import '../widgets/user_avatar.dart';
import '../widgets/verified_badge.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  static const _portfolioColors = [
    Color(0xFFEDE9FE), Color(0xFFCCFBF1), Color(0xFFFFEDD5),
    Color(0xFFCCFBF1), Color(0xFFEDE9FE), Color(0xFFFFEDD5),
  ];

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;
    if (user == null) return const Center(child: CircularProgressIndicator());

    return SingleChildScrollView(
      child: Column(
        children: [
          _buildHero(context, user.initials, user.name, user.profession,
              user.location, user.bio, user.badge, user.isVerified),
          _buildStats(user.postCount, user.followerCount, user.rating, user.reliabilityPercent),
          _buildButtons(),
          _buildSectionLabel('Portfolio'),
          _buildPortfolioGrid(),
          _buildSectionLabel('Badges'),
          _buildBadges(),
          _buildSectionLabel('Avis clients'),
          _buildReviews(),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildHero(BuildContext ctx, String initials, String name,
      String profession, String location, String bio, String badge, bool verified) {
    return Container(
      color: AppColors.white,
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
      child: Column(
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [AppColors.primary, AppColors.primaryLight],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withOpacity(0.3),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Center(
                  child: Text(initials,
                      style: AppTheme.h1(color: Colors.white).copyWith(fontSize: 24)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(name, style: AppTheme.h2()),
              if (verified) ...[
                const SizedBox(width: 6),
                const VerifiedBadge(size: 16),
              ],
              if (badge == 'or') ...[
                const SizedBox(width: 6),
                BadgeChip(label: 'Or', bg: AppColors.goldBg, fg: const Color(0xFF78350F)),
              ] else if (badge == 'argent') ...[
                const SizedBox(width: 6),
                BadgeChip(label: 'Argent', bg: AppColors.borderLight, fg: AppColors.textSecond),
              ],
            ],
          ),
          const SizedBox(height: 4),
          Text('$profession · $location', style: AppTheme.caption()),
          if (bio.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(bio, style: AppTheme.caption(), textAlign: TextAlign.center),
          ],
        ],
      ),
    );
  }

  Widget _buildStats(int posts, int followers, double rating, int reliability) {
    return Container(
      color: AppColors.white,
      child: Row(
        children: [
          _StatCell(value: '$posts',      label: 'Posts'),
          _StatCell(value: followers >= 1000 ? '${(followers/1000).toStringAsFixed(1)}k' : '$followers', label: 'Abonnés'),
          _StatCell(value: '$rating',     label: 'Note'),
          _StatCell(value: '$reliability%', label: 'Fiabilité'),
        ],
      ),
    );
  }

  Widget _buildButtons() {
    return Container(
      color: AppColors.white,
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
      child: Row(
        children: [
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.chat_bubble_outline, size: 16),
              label: const Text('Contacter'),
              style: AppTheme.filledBtn(AppColors.primary),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.person_add_outlined, size: 16),
              label: const Text('Suivre'),
              style: AppTheme.outlineBtn(),
            ),
          ),
          const SizedBox(width: 8),
          OutlinedButton(
            onPressed: () {},
            style: AppTheme.outlineBtn(),
            child: const Text('Devis'),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionLabel(String label) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
      color: AppColors.scaffold,
      child: Text(label,
          style: AppTheme.body(size: 13, color: AppColors.textSecond)
              .copyWith(fontWeight: FontWeight.w700)),
    );
  }

  Widget _buildPortfolioGrid() {
    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
      ),
      itemCount: _portfolioColors.length,
      itemBuilder: (ctx, i) => Container(color: _portfolioColors[i]),
    );
  }

  Widget _buildBadges() {
    return Container(
      color: AppColors.white,
      padding: const EdgeInsets.all(14),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: const [
          BadgeChip(label: '🏆 Expert Plomberie', bg: AppColors.goldBg, fg: Color(0xFF78350F)),
          BadgeChip(label: '✓ Pro Certifié',       bg: AppColors.tealBg,  fg: Color(0xFF134E4A)),
          BadgeChip(label: '⚡ Réponse rapide',    bg: AppColors.primaryBg, fg: Color(0xFF3730A3)),
          BadgeChip(label: '★ 100 Avis',           bg: AppColors.orangeBg, fg: Color(0xFF7C2D12)),
        ],
      ),
    );
  }

  Widget _buildReviews() {
    return Column(
      children: [
        _ReviewTile(
          initials: 'EM',
          color: AppColors.primary,
          name: 'Eric M.',
          stars: 5,
          text: 'Travail impeccable, rapide et professionnel. Très recommandée !',
        ),
        _ReviewTile(
          initials: 'SK',
          color: AppColors.teal,
          name: 'Sandra K.',
          stars: 5,
          text: 'Intervention urgence un dimanche, super service !',
        ),
      ],
    );
  }
}

class _StatCell extends StatelessWidget {
  final String value;
  final String label;
  const _StatCell({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: const BoxDecoration(
          border: Border(
            top: BorderSide(color: AppColors.borderLight),
            bottom: BorderSide(color: AppColors.borderLight),
          ),
        ),
        child: Column(
          children: [
            Text(value, style: AppTheme.h2()),
            const SizedBox(height: 2),
            Text(label, style: AppTheme.caption()),
          ],
        ),
      ),
    );
  }
}

class _ReviewTile extends StatelessWidget {
  final String initials;
  final Color color;
  final String name;
  final int stars;
  final String text;

  const _ReviewTile({
    required this.initials,
    required this.color,
    required this.name,
    required this.stars,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.white,
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          UserAvatar(initials: initials, color: color, radius: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(name, style: AppTheme.body(size: 13)),
                    const SizedBox(width: 6),
                    Row(
                      children: List.generate(
                        stars,
                        (_) => const Icon(Icons.star, color: AppColors.gold, size: 13),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(text, style: AppTheme.caption()),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
