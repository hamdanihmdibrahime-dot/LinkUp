import 'package:flutter/material.dart';
import '../models/user.dart';
import '../utils/constants.dart';
import '../widgets/search_bar.dart';
import '../widgets/user_avatar.dart';
import '../widgets/verified_badge.dart';

class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({super.key});

  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  final _controller = TextEditingController();
  int _tabIndex = 0;
  bool _alertActive = true;

  static const _tabs = ['Pros', 'Entreprises', 'Emplois', 'Ventes'];
  static const _filters = ['Près de moi', 'Disponible', 'Vérifié ✓', 'Note 4+'];

  static const _userColors = [
    Color(0xFF6C63FF),
    Color(0xFF14B8A6),
    Color(0xFFF97316),
    Color(0xFFA78BFA),
    Color(0xFFF59E0B),
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Search bar
        Container(
          color: AppColors.white,
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
          child: LinkUpSearchBar(
            controller: _controller,
            hint: 'Chercher électricien, déménageur…',
            onMic: () {},
          ),
        ),
        // Tabs
        _buildTabs(),
        // Alert banner
        if (_alertActive) _buildAlert(),
        // Filters row
        _buildFilterRow(),
        // Results
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.zero,
            itemCount: kSampleUsers.length,
            itemBuilder: (ctx, i) => _ResultTile(
              user: kSampleUsers[i],
              color: _userColors[i % _userColors.length],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTabs() {
    return Container(
      color: AppColors.white,
      child: Row(
        children: List.generate(_tabs.length, (i) {
          final sel = i == _tabIndex;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _tabIndex = i),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: sel ? AppColors.primary : Colors.transparent,
                      width: 2.5,
                    ),
                  ),
                ),
                child: Text(
                  _tabs[i],
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
                    color: sel ? AppColors.primary : AppColors.textSecond,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildAlert() {
    return Container(
      margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.primaryBg,
        borderRadius: BorderRadius.circular(Rad.md),
        border: const Border(left: BorderSide(color: AppColors.primary, width: 3)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: const BoxDecoration(
              color: AppColors.primary,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.notifications_active, color: Colors.white, size: 16),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Alerte activée : Électricien', style: AppTheme.body(size: 12)),
                Text('Fatou K. est en ligne maintenant', style: AppTheme.caption(color: AppColors.primary)),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => setState(() => _alertActive = false),
            child: const Icon(Icons.close, size: 16, color: AppColors.textSecond),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterRow() {
    return Container(
      height: 42,
      color: AppColors.scaffold,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        itemCount: _filters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (ctx, i) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: i == 0 ? AppColors.primary : AppColors.white,
            borderRadius: BorderRadius.circular(Rad.full),
            border: Border.all(color: i == 0 ? AppColors.primary : AppColors.border),
          ),
          child: Text(
            _filters[i],
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: i == 0 ? Colors.white : AppColors.textSecond,
            ),
          ),
        ),
      ),
    );
  }
}

class _ResultTile extends StatelessWidget {
  final AppUser user;
  final Color color;
  const _ResultTile({required this.user, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: const BoxDecoration(
        color: AppColors.white,
        border: Border(bottom: BorderSide(color: AppColors.borderLight)),
      ),
      child: Row(
        children: [
          Stack(
            children: [
              UserAvatar(initials: user.initials, color: color, radius: 24, isOnline: user.isOnline),
              if (user.badge == 'or')
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      color: AppColors.gold,
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.white, width: 1.5),
                    ),
                    child: const Icon(Icons.star, color: Colors.white, size: 9),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(user.name, style: AppTheme.body(size: 14)),
                    if (user.isVerified) ...[
                      const SizedBox(width: 4),
                      const VerifiedBadge(),
                    ],
                  ],
                ),
                Text('${user.profession} · ${user.location}', style: AppTheme.caption()),
                if (user.rating > 0)
                  Row(
                    children: [
                      const Icon(Icons.star, color: AppColors.gold, size: 13),
                      const SizedBox(width: 3),
                      Text(
                        '${user.rating} (${user.reviewCount} avis)',
                        style: AppTheme.caption(color: AppColors.textSecond),
                      ),
                    ],
                  ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          ElevatedButton(
            onPressed: () {},
            style: AppTheme.filledBtn(AppColors.teal),
            child: const Text('Contacter'),
          ),
        ],
      ),
    );
  }
}
