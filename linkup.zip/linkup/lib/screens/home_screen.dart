import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/notifications_provider.dart';
import '../utils/constants.dart';
import '../widgets/bottom_nav_bar.dart';
import 'feed_screen.dart';
import 'discover_screen.dart';
import 'marketplace_screen.dart';
import 'profile_screen.dart';
import 'messaging_screen.dart';
import 'notifications_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _navIndex = 0;

  static const _screens = [
    FeedScreen(),
    DiscoverScreen(),
    SizedBox(),          // placeholder "+", géré par le sheet
    MarketplaceScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final notifProvider = context.watch<NotificationsProvider>();

    return Scaffold(
      backgroundColor: AppColors.scaffold,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        elevation: 0,
        titleSpacing: 16,
        title: Text(
          'LinkUp',
          style: AppTheme.h1(color: Colors.white).copyWith(
            letterSpacing: 1,
            fontWeight: FontWeight.w800,
          ),
        ),
        actions: [
          _TopBarIcon(
            icon: Icons.chat_bubble_outline,
            badgeCount: 3,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const MessagingScreen()),
            ),
          ),
          _TopBarIcon(
            icon: Icons.notifications_none,
            badgeCount: notifProvider.unreadCount,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const NotificationsScreen()),
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: IndexedStack(index: _navIndex, children: _screens),
      bottomNavigationBar: LinkUpBottomNav(
        currentIndex: _navIndex,
        onTap: (i) {
          if (i == 2) { _showPublishSheet(context); return; }
          setState(() => _navIndex = i);
        },
      ),
    );
  }

  void _showPublishSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Que voulez-vous publier ?', style: AppTheme.h2()),
            const SizedBox(height: 16),
            _PublishOption(icon: Icons.image_outlined,                   label: 'Photo / Vidéo',      color: AppColors.primary),
            _PublishOption(icon: Icons.work_outline,                     label: "Offre d'emploi",     color: AppColors.teal),
            _PublishOption(icon: Icons.sell_outlined,                    label: 'Article à vendre',   color: AppColors.orange),
            _PublishOption(icon: Icons.home_repair_service_outlined,     label: 'Offre de service',   color: AppColors.gold),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

class _TopBarIcon extends StatelessWidget {
  final IconData icon;
  final int badgeCount;
  final VoidCallback onTap;
  const _TopBarIcon({required this.icon, required this.badgeCount, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 24),
            if (badgeCount > 0)
              Positioned(
                top: 4,
                right: 0,
                child: Container(
                  width: 16, height: 16,
                  decoration: BoxDecoration(
                    color: AppColors.red, shape: BoxShape.circle,
                    border: Border.all(color: AppColors.primary, width: 1.5),
                  ),
                  child: Center(
                    child: Text('$badgeCount',
                        style: const TextStyle(fontSize: 9, color: Colors.white, fontWeight: FontWeight.w800)),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _PublishOption extends StatelessWidget {
  final IconData icon; final String label; final Color color;
  const _PublishOption({required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Container(
        width: 44, height: 44,
        decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
        child: Icon(icon, color: color, size: 22),
      ),
      title: Text(label, style: AppTheme.body()),
      trailing: const Icon(Icons.chevron_right, color: AppColors.textSecond),
      onTap: () => Navigator.pop(context),
    );
  }
}
