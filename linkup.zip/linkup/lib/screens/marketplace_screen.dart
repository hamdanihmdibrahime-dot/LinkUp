import 'package:flutter/material.dart';
import '../models/product.dart';
import '../utils/constants.dart';
import '../widgets/search_bar.dart';

class MarketplaceScreen extends StatefulWidget {
  const MarketplaceScreen({super.key});

  @override
  State<MarketplaceScreen> createState() => _MarketplaceScreenState();
}

class _MarketplaceScreenState extends State<MarketplaceScreen> {
  final _controller = TextEditingController();
  int _catIndex = 0;

  static const _cats = ['Tout', 'Services', 'Outils', 'Électronique', 'Artisanat', 'Véhicules'];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          color: AppColors.white,
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
          child: LinkUpSearchBar(controller: _controller, hint: 'Chercher produit ou service…'),
        ),
        _buildCategories(),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(12),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.72,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: kSampleProducts.length,
            itemBuilder: (ctx, i) => _ProductCard(product: kSampleProducts[i]),
          ),
        ),
      ],
    );
  }

  Widget _buildCategories() {
    return Container(
      color: AppColors.scaffold,
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        itemCount: _cats.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (ctx, i) {
          final sel = i == _catIndex;
          return GestureDetector(
            onTap: () => setState(() => _catIndex = i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color: sel ? AppColors.primary : AppColors.white,
                borderRadius: BorderRadius.circular(Rad.full),
                border: Border.all(color: sel ? AppColors.primary : AppColors.border),
              ),
              child: Text(
                _cats[i],
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: sel ? Colors.white : AppColors.textSecond,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  final Product product;
  const _ProductCard({required this.product});

  @override
  Widget build(BuildContext context) {
    final accent = product.accent ?? AppColors.primary;
    return Container(
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(Rad.md),
        border: Border.all(color: AppColors.borderLight),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(Rad.md)),
            child: Stack(
              children: [
                SizedBox(
                  width: double.infinity,
                  height: 120,
                  child: product.imageUrl != null
                      ? Image.network(
                          product.imageUrl!,
                          fit: BoxFit.cover,
                          loadingBuilder: (_, c, p) => p == null
                              ? c
                              : Container(
                                  color: AppColors.shimmer,
                                  child: const Center(
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: AppColors.primary,
                                    ),
                                  ),
                                ),
                        )
                      : Container(color: AppColors.shimmer),
                ),
                if (product.isPromo)
                  Positioned(
                    top: 6,
                    left: 6,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppColors.orange,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Text('Promo',
                          style: TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w700)),
                    ),
                  ),
              ],
            ),
          ),
          // Body
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(product.title, style: AppTheme.body(size: 12), maxLines: 2, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                Text(
                  '${product.price} ${product.currency}',
                  style: AppTheme.body(size: 13, color: AppColors.primary),
                ),
                if (product.isVerified)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Row(
                      children: [
                        const Icon(Icons.verified_user, color: AppColors.teal, size: 12),
                        const SizedBox(width: 3),
                        Text(
                          product.type == ProductType.service ? 'Pro certifié' : 'Vendeur vérifié',
                          style: AppTheme.caption(color: AppColors.teal),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: AppTheme.filledBtn(accent),
                    child: Text(product.ctaLabel),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
