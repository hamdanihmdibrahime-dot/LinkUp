import 'package:flutter/material.dart';
import '../models/notification_item.dart';

class NotificationsProvider extends ChangeNotifier {
  List<NotifItem> _notifs = List.from(kSampleNotifs);

  List<NotifItem> get notifs => _notifs;

  int get unreadCount => _notifs.where((n) => !n.isRead).length;

  void markAllRead() {
    _notifs = _notifs
        .map((n) => NotifItem(
              id: n.id,
              type: n.type,
              title: n.title,
              subtitle: n.subtitle,
              timeAgo: n.timeAgo,
              isRead: true,
            ))
        .toList();
    notifyListeners();
  }

  // TODO: Connecter à Firebase Cloud Messaging
}
