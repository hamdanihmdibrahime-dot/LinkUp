import 'package:flutter/material.dart';
import '../models/user.dart';

class AuthProvider extends ChangeNotifier {
  // Utilisateur connecté simulé (remplacer par Firebase Auth)
  AppUser? _user = kSampleUsers.first;

  AppUser? get user => _user;
  bool get isLoggedIn => _user != null;

  void signOut() {
    _user = null;
    notifyListeners();
  }

  // TODO: Implémenter avec Firebase Auth
  Future<void> signIn(String email, String password) async {
    await Future.delayed(const Duration(milliseconds: 500));
    _user = kSampleUsers.first;
    notifyListeners();
  }
}
