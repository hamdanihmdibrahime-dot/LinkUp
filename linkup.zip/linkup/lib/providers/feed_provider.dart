import 'package:flutter/material.dart';
import '../models/post.dart';

class FeedProvider extends ChangeNotifier {
  List<Post> _posts = List.from(kSamplePosts);
  String _activeFilter = 'Tous';
  bool _loading = false;

  List<Post> get posts => _posts;
  String get activeFilter => _activeFilter;
  bool get loading => _loading;

  final filters = ['Tous', 'Bâtiment', 'Tech', 'Art', 'Cuisine', 'Santé'];

  void setFilter(String f) {
    _activeFilter = f;
    notifyListeners();
  }

  void toggleLike(String postId) {
    _posts = _posts.map((p) {
      if (p.id == postId) {
        return Post(
          id: p.id,
          authorId: p.authorId,
          authorName: p.authorName,
          authorInitials: p.authorInitials,
          authorColor: p.authorColor,
          authorProfession: p.authorProfession,
          timeAgo: p.timeAgo,
          body: p.body,
          imageUrl: p.imageUrl,
          type: p.type,
          domain: p.domain,
          domainColor: p.domainColor,
          ctaLabel: p.ctaLabel,
          ctaColor: p.ctaColor,
          showFollowContact: p.showFollowContact,
          likes: p.likes + 1,
          comments: p.comments,
          isVerified: p.isVerified,
        );
      }
      return p;
    }).toList();
    notifyListeners();
  }

  // TODO: Remplacer par un appel Firestore
  Future<void> refresh() async {
    _loading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 800));
    _loading = false;
    notifyListeners();
  }
}
