// TODO: Implémenter avec Cloud Firestore
// import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  // final _db = FirebaseFirestore.instance;

  // Posts
  Future<List<Map<String, dynamic>>> getPosts() async {
    // final snap = await _db.collection('posts').orderBy('createdAt', descending: true).get();
    // return snap.docs.map((d) => d.data()).toList();
    throw UnimplementedError('Firestore non encore configuré');
  }

  Future<void> createPost(Map<String, dynamic> data) async {
    // await _db.collection('posts').add(data);
    throw UnimplementedError('Firestore non encore configuré');
  }

  // Users
  Future<Map<String, dynamic>?> getUser(String uid) async {
    // final doc = await _db.collection('users').doc(uid).get();
    // return doc.data();
    throw UnimplementedError('Firestore non encore configuré');
  }
}
