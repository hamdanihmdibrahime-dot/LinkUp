// TODO: Implémenter avec Firebase Storage
// import 'package:firebase_storage/firebase_storage.dart';
// import 'dart:io';

class StorageService {
  // final _storage = FirebaseStorage.instance;

  Future<String> uploadImage(String path, List<int> bytes) async {
    // final ref = _storage.ref(path);
    // await ref.putData(Uint8List.fromList(bytes));
    // return await ref.getDownloadURL();
    throw UnimplementedError('Firebase Storage non encore configuré');
  }
}
