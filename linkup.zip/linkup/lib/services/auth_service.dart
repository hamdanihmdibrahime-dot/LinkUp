// TODO: Implémenter avec Firebase Auth
// import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  // final _auth = FirebaseAuth.instance;

  Future<void> signInWithEmail(String email, String password) async {
    // await _auth.signInWithEmailAndPassword(email: email, password: password);
    throw UnimplementedError('Firebase Auth non encore configuré');
  }

  Future<void> signUpWithEmail(String email, String password) async {
    // await _auth.createUserWithEmailAndPassword(email: email, password: password);
    throw UnimplementedError('Firebase Auth non encore configuré');
  }

  Future<void> signOut() async {
    // await _auth.signOut();
  }
}
