import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../utils/constants.dart';

class UserAvatar extends StatelessWidget {
  final String initials;
  final Color color;
  final double radius;
  final String? imageUrl;
  final bool isOnline;

  const UserAvatar({
    super.key,
    required this.initials,
    required this.color,
    this.radius = 20,
    this.imageUrl,
    this.isOnline = false,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          width: radius * 2,
          height: radius * 2,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color,
          ),
          child: imageUrl != null
              ? ClipOval(child: Image.network(imageUrl!, fit: BoxFit.cover))
              : Center(
                  child: Text(
                    initials,
                    style: GoogleFonts.nunito(
                      fontSize: radius * 0.6,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
        ),
        if (isOnline)
          Positioned(
            bottom: 0,
            right: 0,
            child: Container(
              width: radius * 0.55,
              height: radius * 0.55,
              decoration: BoxDecoration(
                color: AppColors.green,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.white, width: 1.5),
              ),
            ),
          ),
      ],
    );
  }
}

/// Story ring around avatar
class StoryRing extends StatelessWidget {
  final Widget child;
  final bool hasStory;
  final bool isViewed;

  const StoryRing({
    super.key,
    required this.child,
    this.hasStory = true,
    this.isViewed = false,
  });

  @override
  Widget build(BuildContext context) {
    if (!hasStory) return child;
    return Container(
      padding: const EdgeInsets.all(2),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: isViewed
            ? const LinearGradient(colors: [Color(0xFFD1D5DB), Color(0xFF9CA3AF)])
            : const LinearGradient(
                colors: [AppColors.primary, AppColors.primaryLight],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
      ),
      child: Container(
        padding: const EdgeInsets.all(2),
        decoration: const BoxDecoration(
          shape: BoxShape.circle,
          color: AppColors.white,
        ),
        child: child,
      ),
    );
  }
}
