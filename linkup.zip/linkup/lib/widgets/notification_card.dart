import 'package:flutter/material.dart';
import '../models/notification_item.dart';
import '../utils/constants.dart';

class NotificationCard extends StatelessWidget {
  final NotifItem notif;
  const NotificationCard({super.key, required this.notif});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: notif.isRead ? AppColors.white : AppColors.primaryBg.withOpacity(0.5),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: notif.bgColor,
              shape: BoxShape.circle,
            ),
            child: Icon(notif.icon, color: notif.iconColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(notif.title,
                    style: AppTheme.body(size: 13)
                        .copyWith(fontWeight: notif.isRead ? FontWeight.w600 : FontWeight.w800)),
                const SizedBox(height: 3),
                Text(notif.subtitle, style: AppTheme.caption()),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(notif.timeAgo, style: AppTheme.caption(color: AppColors.textHint)),
        ],
      ),
    );
  }
}
