import 'package:flutter/material.dart';
import '../utils/constants.dart';

class LinkUpSearchBar extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final VoidCallback? onMic;

  const LinkUpSearchBar({
    super.key,
    required this.controller,
    this.hint = 'Rechercher...',
    this.onMic,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 46,
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(Rad.full),
        border: Border.all(color: AppColors.border),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          const SizedBox(width: 14),
          Icon(Icons.search, color: AppColors.textSecond, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: controller,
              style: AppTheme.body(size: 13),
              decoration: InputDecoration(
                border: InputBorder.none,
                isDense: true,
                contentPadding: EdgeInsets.zero,
                hintText: hint,
                hintStyle: AppTheme.caption(color: AppColors.textHint),
                filled: false,
              ),
            ),
          ),
          if (onMic != null)
            GestureDetector(
              onTap: onMic,
              child: Padding(
                padding: const EdgeInsets.only(right: 12),
                child: Icon(Icons.mic_none, color: AppColors.primary, size: 20),
              ),
            ),
        ],
      ),
    );
  }
}
