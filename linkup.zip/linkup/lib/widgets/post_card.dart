import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/post.dart';
import '../utils/constants.dart';
import 'user_avatar.dart';
import 'verified_badge.dart';

class PostCard extends StatefulWidget {
  final Post post;
  final VoidCallback? onLike;

  const PostCard({super.key, required this.post, this.onLike});

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  bool _liked = false;

  @override
  Widget build(BuildContext context) {
    final p = widget.post;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      color: AppColors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(p),
          if (p.body.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 8),
              child: Text(p.body, style: AppTheme.body()),
            ),
          if (p.imageUrl != null) _buildImage(p),
          _buildActions(p),
        ],
      ),
    );
  }

  Widget _buildHeader(Post p) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
      child: Row(
        children: [
          UserAvatar(initials: p.authorInitials, color: p.authorColor),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(p.authorName, style: AppTheme.body(size: 14)),
                    if (p.isVerified) ...[
                      const SizedBox(width: 4),
                      const VerifiedBadge(),
                    ],
                  ],
                ),
                Text('${p.authorProfession} · ${p.timeAgo}',
                    style: AppTheme.caption()),
              ],
            ),
          ),
          Icon(Icons.more_vert, color: AppColors.textSecond, size: 20),
        ],
      ),
    );
  }

  Widget _buildImage(Post p) {
    return Stack(
      children: [
        Container(
          width: double.infinity,
          height: 200,
          color: AppColors.shimmer,
          child: Image.network(
            p.imageUrl!,
            fit: BoxFit.cover,
            loadingBuilder: (_, child, progress) =>
                progress == null ? child : const _ImageShimmer(),
            errorBuilder: (_, __, ___) => const _ImageShimmer(),
          ),
        ),
        if (p.domain != null)
          Positioned(
            bottom: 8,
            left: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(
                color: p.domainColor ?? AppColors.primary,
                borderRadius: BorderRadius.circular(Rad.full),
              ),
              child: Text(p.domain!,
                  style: GoogleFonts.nunito(
                      fontSize: 11, color: Colors.white, fontWeight: FontWeight.w700)),
            ),
          ),
      ],
    );
  }

  Widget _buildActions(Post p) {
    if (p.showFollowContact) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
        child: Row(
          children: [
            OutlinedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.person_add_outlined, size: 15),
              label: const Text('Suivre'),
              style: AppTheme.outlineBtn(),
            ),
            const SizedBox(width: 8),
            ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.chat_bubble_outline, size: 15),
              label: const Text('Contacter'),
              style: AppTheme.filledBtn(AppColors.primary),
            ),
            const Spacer(),
            _actionIcon(
              icon: _liked ? Icons.favorite : Icons.favorite_outline,
              color: _liked ? AppColors.red : AppColors.textSecond,
              count: p.likes + (_liked ? 1 : 0),
              onTap: () { setState(() => _liked = !_liked); widget.onLike?.call(); },
            ),
            const SizedBox(width: 14),
            _actionIcon(icon: Icons.chat_bubble_outline, count: p.comments, onTap: () {}),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
      child: Row(
        children: [
          _actionIcon(
            icon: _liked ? Icons.favorite : Icons.favorite_outline,
            color: _liked ? AppColors.red : AppColors.textSecond,
            count: p.likes + (_liked ? 1 : 0),
            onTap: () => setState(() => _liked = !_liked),
          ),
          const SizedBox(width: 14),
          _actionIcon(icon: Icons.chat_bubble_outline, count: p.comments, onTap: () {}),
          const SizedBox(width: 14),
          GestureDetector(
            onTap: () {},
            child: Icon(Icons.share_outlined, size: 20, color: AppColors.textSecond),
          ),
          const Spacer(),
          if (p.ctaLabel != null)
            ElevatedButton(
              onPressed: () {},
              style: AppTheme.filledBtn(p.ctaColor ?? AppColors.primary),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(p.ctaLabel!),
                  const SizedBox(width: 4),
                  const Icon(Icons.chevron_right, size: 16),
                ],
              ),
            ),
          GestureDetector(
            onTap: () {},
            child: Padding(
              padding: const EdgeInsets.only(left: 14),
              child: Icon(Icons.bookmark_outline, size: 20, color: AppColors.textSecond),
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionIcon({
    required IconData icon,
    int count = 0,
    Color? color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          Icon(icon, size: 20, color: color ?? AppColors.textSecond),
          if (count > 0) ...[
            const SizedBox(width: 4),
            Text('$count', style: AppTheme.caption()),
          ],
        ],
      ),
    );
  }
}

class _ImageShimmer extends StatelessWidget {
  const _ImageShimmer();
  @override
  Widget build(BuildContext context) => Container(color: AppColors.shimmer,
      child: const Center(child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary)));
}
