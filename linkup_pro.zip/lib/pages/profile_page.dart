import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF1877F2), Color(0xFF42A5F5)],
              ),
            ),
            child: const Column(
              children: [
                CircleAvatar(radius: 45),
                SizedBox(height: 10),
                Text('Nom utilisateur', style: TextStyle(color: Colors.white)),
              ],
            ),
          ).animate().fade(),
          const SizedBox(height: 20),
          const ListTile(
            leading: Icon(Icons.settings),
            title: Text('Paramètres'),
          ),
        ],
      ),
    );
  }
}
