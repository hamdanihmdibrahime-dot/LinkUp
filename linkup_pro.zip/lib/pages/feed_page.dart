import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

class FeedPage extends StatelessWidget {
  const FeedPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 6,
      itemBuilder: (context, index) {
        return Card(
          margin: const EdgeInsets.all(12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: ListTile(
            leading: const CircleAvatar(),
            title: Text('User $index'),
            subtitle: const Text('Post moderne'),
          ),
        ).animate().fade().slideY(begin: 0.2);
      },
    );
  }
}
