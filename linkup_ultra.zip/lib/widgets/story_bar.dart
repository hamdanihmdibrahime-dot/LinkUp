import 'package:flutter/material.dart';

class StoryBar extends StatelessWidget {
  const StoryBar({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: 10,
        itemBuilder: (context, i) {
          return Padding(
            padding: const EdgeInsets.all(8),
            child: Column(
              children: const [
                CircleAvatar(radius: 30),
                SizedBox(height: 5),
                Text('Story'),
              ],
            ),
          );
        },
      ),
    );
  }
}
