import 'package:flutter/material.dart';

class PostCard extends StatelessWidget {
  final int index;

  const PostCard({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              children: [
                const CircleAvatar(),
                const SizedBox(width: 10),
                Text('User $index'),
              ],
            ),
            const SizedBox(height: 10),
            const Text('Post avec design moderne 🔥'),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: const [
                Icon(Icons.favorite_border),
                Icon(Icons.comment),
                Icon(Icons.share),
              ],
            )
          ],
        ),
      ),
    );
  }
}
