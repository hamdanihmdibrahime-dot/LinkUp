import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: const [
        SizedBox(height: 50),
        CircleAvatar(radius: 50),
        SizedBox(height: 10),
        Text('Profil utilisateur'),
      ],
    );
  }
}
