import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/post_card.dart';
import '../widgets/story_bar.dart';

class FeedPage extends StatelessWidget {
  const FeedPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        const StoryBar(),
        ...List.generate(5, (i) => PostCard(index: i)
            .animate()
            .fade()
            .slideY(begin: 0.2)),
      ],
    );
  }
}
