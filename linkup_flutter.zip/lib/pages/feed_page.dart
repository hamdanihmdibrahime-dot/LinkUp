import 'package:flutter/material.dart';

class FeedPage extends StatelessWidget {
  const FeedPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 5,
      itemBuilder: (context, index) {
        return Card(
          margin: const EdgeInsets.all(12),
          child: ListTile(
            leading: const CircleAvatar(),
            title: Text('User $index'),
            subtitle: const Text('Post moderne'),
          ),
        );
      },
    );
  }
}
