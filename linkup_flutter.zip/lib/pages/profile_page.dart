import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          width: double.infinity,
          color: Colors.blue,
          child: const Column(
            children: [
              CircleAvatar(radius: 40),
              SizedBox(height: 10),
              Text('Nom utilisateur', style: TextStyle(color: Colors.white)),
            ],
          ),
        ),
        const ListTile(
          leading: Icon(Icons.settings),
          title: Text('Paramètres'),
        ),
      ],
    );
  }
}
